# RaceDay – Full Solution (API + MVC)

Complete Part 3 solution:

- **RaceDay.Api** – ASP.NET Core 8 Web API with EF Core, session auth, Azure Blob Storage
- **RaceDay.Web** – ASP.NET Core 8 MVC front-end that consumes the API
- **RaceDay.Api.Tests** – (placeholder for your existing tests)

## Quick start in Visual Studio

1. Extract this folder.
2. Double-click **`RaceDay.sln`**.
3. Right-click the **solution** → **Properties** → **Startup Project** → **Multiple startup projects**.
4. Set both **RaceDay.Api** and **RaceDay.Web** to **Start**.
5. Press **F5**.

- API Swagger: https://localhost:7101/swagger  
- MVC app: https://localhost:7201

## First-time database setup

From the `RaceDay.Api` folder (or Package Manager Console with RaceDay.Api as default project):

```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

Or just run the API once — `Program.cs` calls `db.Database.Migrate()` in Development.

## Organiser access code

Default code (in `appsettings.json`):

```
RACE-ORGANISER-2024
```

Use this when registering an Organiser account.

## Azure Blob Storage (optional for images)

```bash
cd RaceDay.Api
dotnet user-secrets set "AzureStorage:ConnectionString" "YOUR_CONNECTION_STRING"
```

Without it, image uploads return 503 (the rest of the app still works).

## Project layout

```
RaceDay/
├── RaceDay.sln
├── RaceDay.Api/          ← REST API
├── RaceDay.Web/          ← MVC front-end
└── RaceDay.Api.Tests/    ← unit tests (add your existing ones)
```

## Important ports

| Project       | HTTPS           | HTTP            |
|---------------|-----------------|-----------------|
| RaceDay.Api   | localhost:7101  | localhost:5101  |
| RaceDay.Web   | localhost:7201  | localhost:5201  |

The MVC `appsettings.Development.json` already points at `https://localhost:7101/`.

## Docker (MVC only)

```bash
cd RaceDay.Web
docker build -t raceday-web .
docker run -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:5101/ raceday-web
```
