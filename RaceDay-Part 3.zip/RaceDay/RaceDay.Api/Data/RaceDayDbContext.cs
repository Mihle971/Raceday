using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public class RaceDayDbContext : DbContext
{
    public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<User> Users => Set<User>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // ---- Role ----
        modelBuilder.Entity<Role>(e =>
        {
            e.ToTable("Role");
            e.HasKey(r => r.RoleId);
            e.Property(r => r.RoleName).HasMaxLength(50).IsRequired();
            e.HasIndex(r => r.RoleName).IsUnique();
            e.HasData(
                new Role { RoleId = 1, RoleName = "Organiser" },
                new Role { RoleId = 2, RoleName = "Participant" });
        });

        // ---- User ----
        modelBuilder.Entity<User>(e =>
        {
            e.ToTable("User");
            e.HasKey(u => u.UserId);
            e.Property(u => u.FirstName).HasMaxLength(50).IsRequired();
            e.Property(u => u.LastName).HasMaxLength(50).IsRequired();
            e.Property(u => u.Email).HasMaxLength(100).IsRequired();
            e.HasIndex(u => u.Email).IsUnique();
            e.Property(u => u.PasswordHash).HasMaxLength(255).IsRequired();
            e.Property(u => u.DateRegistered).HasDefaultValueSql("GETDATE()");
            e.Property(u => u.ProfilePictureUrl).HasMaxLength(500);
            e.HasOne(u => u.Role).WithMany(r => r.Users)
                .HasForeignKey(u => u.RoleId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---- Event ----
        modelBuilder.Entity<Event>(e =>
        {
            e.ToTable("Event", t =>
            {
                t.HasCheckConstraint("CK_Event_Distance", "[Distance] > 0");
                t.HasCheckConstraint("CK_Event_EventType", "[EventType] IN ('Run','Walk','Cycle')");
            });
            e.HasKey(x => x.EventId);
            e.Property(x => x.EventName).HasMaxLength(100).IsRequired();
            e.Property(x => x.EventDate).HasColumnType("date");
            e.Property(x => x.Location).HasMaxLength(100).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500);
            e.Property(x => x.Distance).HasColumnType("decimal(6,2)");
            e.Property(x => x.EventType).HasMaxLength(10).IsRequired();
            e.Property(x => x.BannerUrl).HasMaxLength(500);
            e.HasOne(x => x.Organiser).WithMany(u => u.OrganisedEvents)
                .HasForeignKey(x => x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---- Category ----
        modelBuilder.Entity<Category>(e =>
        {
            e.ToTable("Category");
            e.HasKey(c => c.CategoryId);
            e.Property(c => c.CategoryName).HasMaxLength(50).IsRequired();
            e.Property(c => c.MaxParticipants).HasDefaultValue(100);
            e.HasOne(c => c.Event).WithMany(ev => ev.Categories)
                .HasForeignKey(c => c.EventId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---- Enrolment ----
        modelBuilder.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolment", t =>
            {
                t.HasCheckConstraint("CK_Enrolment_Status", "[Status] IN ('Pending','Confirmed')");
            });
            e.HasKey(x => x.EnrolmentId);
            e.Property(x => x.EnrolmentDate).HasDefaultValueSql("GETDATE()");
            e.Property(x => x.Status).HasMaxLength(20).IsRequired().HasDefaultValue("Pending");
            e.HasOne(x => x.User).WithMany(u => u.Enrolments)
                .HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Category).WithMany(c => c.Enrolments)
                .HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new { x.UserId, x.CategoryId }).IsUnique()
                .HasDatabaseName("UQ_Enrolment_UserCategory");
        });

        // ---- Result ----
        modelBuilder.Entity<Result>(e =>
        {
            e.ToTable("Result");
            e.HasKey(r => r.ResultId);
            e.Property(r => r.FinishTime).HasColumnType("time");
            e.Property(r => r.CapturedDate).HasDefaultValueSql("GETDATE()");
            e.Property(r => r.IsPublished).HasDefaultValue(false);
            e.HasOne(r => r.Enrolment).WithOne(en => en.Result)
                .HasForeignKey<Result>(r => r.EnrolmentId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}
