namespace RaceDay.Api.Security;

public static class SessionExtensions
{
    private const string UserIdKey = "UserId";
    private const string RoleKey = "Role";

    public static void SetSessionUser(this HttpContext ctx, int userId, string role)
    {
        ctx.Session.SetInt32(UserIdKey, userId);
        ctx.Session.SetString(RoleKey, role);
    }

    public static int? GetSessionUserId(this HttpContext ctx) =>
        ctx.Session.GetInt32(UserIdKey);

    public static string? GetSessionRole(this HttpContext ctx) =>
        ctx.Session.GetString(RoleKey);

    public static void ClearSessionUser(this HttpContext ctx)
    {
        ctx.Session.Remove(UserIdKey);
        ctx.Session.Remove(RoleKey);
    }
}
