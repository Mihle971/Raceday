using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Api.Security;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    public string? Roles { get; set; }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var userId = context.HttpContext.GetSessionUserId();
        if (userId == null)
        {
            context.Result = new UnauthorizedObjectResult(new ProblemDetails
            {
                Status = 401,
                Title = "Unauthorized",
                Detail = "You must be logged in."
            });
            return;
        }

        if (!string.IsNullOrEmpty(Roles))
        {
            var role = context.HttpContext.GetSessionRole();
            var allowed = Roles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (role == null || !allowed.Contains(role, StringComparer.OrdinalIgnoreCase))
            {
                context.Result = new ObjectResult(new ProblemDetails
                {
                    Status = 403,
                    Title = "Forbidden",
                    Detail = "You do not have permission to perform this action."
                })
                { StatusCode = 403 };
            }
        }
    }
}
