using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class ResultsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public ResultsController(RaceDayDbContext db) => _db = db;

    [HttpPost("enrolments/{enrolmentId:int}/results")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Capture(int enrolmentId, [FromBody] ResultRequest request)
    {
        var enrolment = await _db.Enrolments
            .Include(e => e.Category).ThenInclude(c => c.Event)
            .Include(e => e.Result)
            .SingleOrDefaultAsync(e => e.EnrolmentId == enrolmentId);

        if (enrolment == null) return NotFoundProblem("Enrolment not found.");
        if (enrolment.Category.Event.OrganiserId != CurrentUserId)
            return ForbiddenProblem("You can only capture results for your own events.");
        if (enrolment.Result != null)
            return ConflictProblem("A result has already been captured for this enrolment.");

        var result = new Result
        {
            EnrolmentId = enrolmentId,
            FinishTime = request.FinishTime!.Value,
            Position = request.Position,
            CapturedDate = DateTime.UtcNow,
            IsPublished = false
        };
        _db.Results.Add(result);
        await _db.SaveChangesAsync();

        var response = await _db.Results
            .Where(r => r.ResultId == result.ResultId)
            .Select(Mapping.ResultProjection)
            .SingleAsync();

        return Created($"/api/results/{result.ResultId}", response);
    }

    [HttpGet("users/{userId:int}/results")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetForUser(int userId)
    {
        if (userId != CurrentUserId && CurrentRole != "Organiser")
            return ForbiddenProblem("You can only view your own results.");

        // Participants only see published results; organisers can see everything for any user if needed
        var query = _db.Results.Where(r => r.Enrolment.UserId == userId);
        if (userId == CurrentUserId && CurrentRole == "Participant")
            query = query.Where(r => r.IsPublished);

        var list = await query.Select(Mapping.ResultProjection).ToListAsync();
        return Ok(list);
    }
}
