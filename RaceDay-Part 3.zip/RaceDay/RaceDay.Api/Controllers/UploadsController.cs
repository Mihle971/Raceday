using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

public class UploadsController : ApiControllerBase
{
    private const long MaxBytes = 2 * 1024 * 1024;
    private static readonly Dictionary<string, string> AllowedTypes = new()
    {
        ["image/jpeg"] = ".jpg",
        ["image/png"] = ".png",
        ["image/webp"] = ".webp"
    };

    private readonly RaceDayDbContext _db;
    private readonly IFileStorageService _storage;

    public UploadsController(RaceDayDbContext db, IFileStorageService storage)
    {
        _db = db;
        _storage = storage;
    }

    private static string? ValidateImage(IFormFile? file)
    {
        if (file == null || file.Length == 0) return "Please choose an image file.";
        if (file.Length > MaxBytes) return "The image must be 2 MB or smaller.";
        if (!AllowedTypes.ContainsKey(file.ContentType)) return "Only JPG, PNG or WebP images are allowed.";
        return null;
    }

    private async Task<string> SaveAsync(IFormFile file, string folder, int id)
    {
        var blobName = $"{folder}/{id}-{Guid.NewGuid():N}{AllowedTypes[file.ContentType]}";
        await using var stream = file.OpenReadStream();
        return await _storage.UploadAsync(stream, blobName, file.ContentType);
    }

    [HttpPost("api/events/{eventId:int}/banner")]
    [SessionAuthorize(Roles = "Organiser")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> UploadBanner(int eventId, IFormFile file)
    {
        var ev = await _db.Events.FindAsync(eventId);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only upload banners for your own events.");

        var error = ValidateImage(file);
        if (error != null) return BadRequestProblem(error);

        try
        {
            ev.BannerUrl = await SaveAsync(file, "banners", eventId);
        }
        catch (InvalidOperationException)
        {
            return ServiceUnavailableProblem("File storage is not available right now.");
        }

        await _db.SaveChangesAsync();
        return Ok(ev.ToResponse());
    }

    [HttpPost("api/users/{userId:int}/profile-picture")]
    [SessionAuthorize]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> UploadProfilePicture(int userId, IFormFile file)
    {
        if (userId != CurrentUserId) return ForbiddenProblem("You can only change your own profile picture.");

        var user = await _db.Users.Include(u => u.Role).SingleOrDefaultAsync(u => u.UserId == userId);
        if (user == null) return NotFoundProblem("User not found.");

        var error = ValidateImage(file);
        if (error != null) return BadRequestProblem(error);

        try
        {
            user.ProfilePictureUrl = await SaveAsync(file, "profiles", userId);
        }
        catch (InvalidOperationException)
        {
            return ServiceUnavailableProblem("File storage is not available right now.");
        }

        await _db.SaveChangesAsync();
        return Ok(user.ToResponse(user.Role.RoleName));
    }
}
