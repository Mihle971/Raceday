using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class EnrolmentsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public EnrolmentsController(RaceDayDbContext db) => _db = db;

    [HttpGet("users/{userId:int}/enrolments")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetForUser(int userId)
    {
        if (userId != CurrentUserId && CurrentRole != "Organiser")
            return ForbiddenProblem("You can only view your own enrolments.");

        var list = await _db.Enrolments
            .Where(e => e.UserId == userId)
            .Select(Mapping.EnrolmentProjection)
            .ToListAsync();
        return Ok(list);
    }

    [HttpPut("enrolments/{id:int}/status")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] EnrolmentStatusRequest request)
    {
        var enrolment = await _db.Enrolments
            .Include(e => e.Category).ThenInclude(c => c.Event)
            .SingleOrDefaultAsync(e => e.EnrolmentId == id);

        if (enrolment == null) return NotFoundProblem("Enrolment not found.");
        if (enrolment.Category.Event.OrganiserId != CurrentUserId)
            return ForbiddenProblem("You can only update enrolments for your own events.");

        var status = request.Status?.Trim();
        if (status is not ("Pending" or "Confirmed"))
            return BadRequestProblem("Status must be 'Pending' or 'Confirmed'.");

        // Normalise casing
        enrolment.Status = status == "Confirmed" ? "Confirmed" : "Pending";
        await _db.SaveChangesAsync();

        var response = await _db.Enrolments
            .Where(e => e.EnrolmentId == id)
            .Select(Mapping.EnrolmentProjection)
            .SingleAsync();
        return Ok(response);
    }
}
