using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private static readonly string[] ValidTypes = { "Run", "Walk", "Cycle" };
    private readonly RaceDayDbContext _db;

    public EventsController(RaceDayDbContext db) => _db = db;

    private static string? NormaliseType(string type) =>
        ValidTypes.FirstOrDefault(v => v.Equals(type.Trim(), StringComparison.OrdinalIgnoreCase));

    [HttpGet]
    [ProducesResponseType(typeof(List<EventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetAll(string? eventType = null, string? location = null,
        DateTime? fromDate = null, DateTime? toDate = null, bool upcomingOnly = false)
    {
        var query = _db.Events.AsQueryable();

        if (!string.IsNullOrWhiteSpace(eventType))
        {
            var type = NormaliseType(eventType);
            if (type == null) return BadRequestProblem("eventType must be 'Run', 'Walk' or 'Cycle'.");
            query = query.Where(e => e.EventType == type);
        }
        if (!string.IsNullOrWhiteSpace(location))
        {
            var place = location.Trim();
            query = query.Where(e => e.Location.Contains(place));
        }
        if (fromDate != null)
            query = query.Where(e => e.EventDate >= fromDate.Value.Date);
        if (toDate != null)
            query = query.Where(e => e.EventDate <= toDate.Value.Date);
        if (upcomingOnly)
            query = query.Where(e => e.EventDate >= DateTime.Today);

        var events = await query.OrderBy(e => e.EventDate).ToListAsync();
        return Ok(events.Select(e => e.ToResponse()).ToList());
    }

    [HttpGet("mine")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(List<OrganiserEventSummary>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMine()
    {
        var list = await _db.Events
            .Where(e => e.OrganiserId == CurrentUserId)
            .Select(e => new OrganiserEventSummary
            {
                EventId = e.EventId,
                EventName = e.EventName,
                EventDate = e.EventDate,
                Location = e.Location,
                Distance = e.Distance,
                EventType = e.EventType,
                BannerUrl = e.BannerUrl,
                CategoryCount = e.Categories.Count,
                TotalEnrolments = e.Categories.SelectMany(c => c.Enrolments).Count(),
                PendingEnrolments = e.Categories.SelectMany(c => c.Enrolments).Count(en => en.Status == "Pending"),
                ResultsPublished = e.Categories.SelectMany(c => c.Enrolments)
                    .Count(en => en.Result != null && en.Result.IsPublished)
            })
            .OrderBy(e => e.EventDate)
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id)
    {
        var ev = await _db.Events.FindAsync(id);
        if (ev == null) return NotFoundProblem("Event not found.");
        return Ok(ev.ToResponse());
    }

    [HttpPost]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] EventRequest request)
    {
        if (!ModelState.IsValid) return BadRequestProblem("Invalid event data.");

        var type = NormaliseType(request.EventType);
        if (type == null) return BadRequestProblem("EventType must be 'Run', 'Walk' or 'Cycle'.");

        var ev = new Event
        {
            EventName = request.EventName.Trim(),
            EventDate = request.EventDate!.Value.Date,
            Location = request.Location.Trim(),
            Description = request.Description?.Trim(),
            Distance = request.Distance!.Value,
            EventType = type,
            OrganiserId = CurrentUserId
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = ev.EventId }, ev.ToResponse());
    }

    [HttpPut("{id:int}")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, [FromBody] EventRequest request)
    {
        var ev = await _db.Events.FindAsync(id);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only edit your own events.");

        var type = NormaliseType(request.EventType);
        if (type == null) return BadRequestProblem("EventType must be 'Run', 'Walk' or 'Cycle'.");

        ev.EventName = request.EventName.Trim();
        ev.EventDate = request.EventDate!.Value.Date;
        ev.Location = request.Location.Trim();
        ev.Description = request.Description?.Trim();
        ev.Distance = request.Distance!.Value;
        ev.EventType = type;

        await _db.SaveChangesAsync();
        return Ok(ev.ToResponse());
    }

    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await _db.Events.FindAsync(id);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only delete your own events.");

        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("{eventId:int}/categories")]
    [ProducesResponseType(typeof(List<CategoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCategories(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventId == eventId))
            return NotFoundProblem("Event not found.");

        var cats = await _db.Categories.Where(c => c.EventId == eventId).ToListAsync();
        return Ok(cats.Select(c => c.ToResponse()).ToList());
    }

    [HttpPost("{eventId:int}/categories")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> AddCategory(int eventId, [FromBody] CategoryRequest request)
    {
        var ev = await _db.Events.FindAsync(eventId);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only add categories to your own events.");

        var cat = new Category
        {
            EventId = eventId,
            CategoryName = request.CategoryName.Trim(),
            MaxParticipants = request.MaxParticipants
        };
        _db.Categories.Add(cat);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetCategories), new { eventId }, cat.ToResponse());
    }

    [HttpGet("{eventId:int}/enrolments")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEnrolments(int eventId)
    {
        var ev = await _db.Events.FindAsync(eventId);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only view enrolments for your own events.");

        var list = await _db.Enrolments
            .Where(e => e.Category.EventId == eventId)
            .Select(Mapping.EnrolmentProjection)
            .ToListAsync();
        return Ok(list);
    }

    [HttpGet("{eventId:int}/results")]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetResults(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventId == eventId))
            return NotFoundProblem("Event not found.");

        var isOwner = HttpContext.GetSessionUserId() != null
                      && await _db.Events.AnyAsync(e => e.EventId == eventId && e.OrganiserId == CurrentUserId);

        var query = _db.Results.Where(r => r.Enrolment.Category.EventId == eventId);
        if (!isOwner)
            query = query.Where(r => r.IsPublished);

        var list = await query.Select(Mapping.ResultProjection).ToListAsync();
        return Ok(list);
    }

    [HttpPost("{eventId:int}/results/publish")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> PublishResults(int eventId)
    {
        var ev = await _db.Events.FindAsync(eventId);
        if (ev == null) return NotFoundProblem("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenProblem("You can only publish results for your own events.");

        var results = await _db.Results
            .Where(r => r.Enrolment.Category.EventId == eventId && !r.IsPublished)
            .ToListAsync();

        foreach (var r in results)
            r.IsPublished = true;

        await _db.SaveChangesAsync();
        return Ok(new { published = results.Count });
    }
}
