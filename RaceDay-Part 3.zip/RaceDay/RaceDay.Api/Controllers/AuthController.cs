using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IConfiguration _config;

    public AuthController(RaceDayDbContext db, IConfiguration config)
    {
        _db = db;
        _config = config;
    }

    [HttpPost("register")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        if (!ModelState.IsValid) return BadRequestProblem("Invalid registration data.");

        var roleName = request.Role?.Trim();
        if (roleName is not ("Organiser" or "Participant"))
            return BadRequestProblem("Role must be 'Organiser' or 'Participant'.");

        if (roleName == "Organiser")
        {
            var code = _config["OrganiserAccessCode"];
            if (string.IsNullOrWhiteSpace(request.OrganiserCode) ||
                !string.Equals(request.OrganiserCode, code, StringComparison.Ordinal))
                return BadRequestProblem("Invalid organiser access code.");
        }

        if (await _db.Users.AnyAsync(u => u.Email == request.Email))
            return ConflictProblem("An account with this email already exists.");

        var role = await _db.Roles.SingleAsync(r => r.RoleName == roleName);
        var user = new User
        {
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Email = request.Email.Trim().ToLowerInvariant(),
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            RoleId = role.RoleId,
            DateRegistered = DateTime.UtcNow
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        HttpContext.SetSessionUser(user.UserId, roleName);
        return CreatedAtAction(nameof(Me), user.ToResponse(roleName));
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var user = await _db.Users.Include(u => u.Role)
            .SingleOrDefaultAsync(u => u.Email == request.Email.Trim().ToLowerInvariant());

        if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
            return UnauthorizedProblem("Invalid email or password.");

        HttpContext.SetSessionUser(user.UserId, user.Role.RoleName);
        return Ok(user.ToResponse(user.Role.RoleName));
    }

    [HttpPost("logout")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Logout()
    {
        HttpContext.ClearSessionUser();
        return Ok(new { message = "Logged out." });
    }

    [HttpGet("me")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Me()
    {
        var user = await _db.Users.Include(u => u.Role)
            .SingleOrDefaultAsync(u => u.UserId == CurrentUserId);
        if (user == null) return UnauthorizedProblem("Session invalid.");
        return Ok(user.ToResponse(user.Role.RoleName));
    }
}
