using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[ApiController]
public abstract class ApiControllerBase : ControllerBase
{
    protected int CurrentUserId => HttpContext.GetSessionUserId()!.Value;
    protected string CurrentRole => HttpContext.GetSessionRole()!;

    private static IActionResult ErrorResult(int status, string title, string detail) =>
        new ObjectResult(new ProblemDetails { Status = status, Title = title, Detail = detail })
        {
            StatusCode = status
        };

    protected IActionResult BadRequestProblem(string detail) => ErrorResult(400, "Bad Request", detail);
    protected IActionResult UnauthorizedProblem(string detail) => ErrorResult(401, "Unauthorized", detail);
    protected IActionResult ForbiddenProblem(string detail) => ErrorResult(403, "Forbidden", detail);
    protected IActionResult NotFoundProblem(string detail) => ErrorResult(404, "Not Found", detail);
    protected IActionResult ConflictProblem(string detail) => ErrorResult(409, "Conflict", detail);
    protected IActionResult ServiceUnavailableProblem(string detail) => ErrorResult(503, "Service Unavailable", detail);
}
