using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api/categories")]
public class CategoriesController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public CategoriesController(RaceDayDbContext db) => _db = db;

    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles = "Organiser")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var cat = await _db.Categories.Include(c => c.Event).SingleOrDefaultAsync(c => c.CategoryId == id);
        if (cat == null) return NotFoundProblem("Category not found.");
        if (cat.Event.OrganiserId != CurrentUserId)
            return ForbiddenProblem("You can only delete categories on your own events.");

        _db.Categories.Remove(cat);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPost("{categoryId:int}/enrolments")]
    [SessionAuthorize(Roles = "Participant")]
    [ProducesResponseType(typeof(Dtos.EnrolmentResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Enrol(int categoryId)
    {
        var cat = await _db.Categories.Include(c => c.Event).SingleOrDefaultAsync(c => c.CategoryId == categoryId);
        if (cat == null) return NotFoundProblem("Category not found.");

        var already = await _db.Enrolments.AnyAsync(e => e.UserId == CurrentUserId && e.CategoryId == categoryId);
        if (already) return ConflictProblem("You are already enrolled in this category.");

        var count = await _db.Enrolments.CountAsync(e => e.CategoryId == categoryId);
        if (count >= cat.MaxParticipants)
            return ConflictProblem("This category is full.");

        var enrolment = new Models.Enrolment
        {
            UserId = CurrentUserId,
            CategoryId = categoryId,
            EnrolmentDate = DateTime.UtcNow,
            Status = "Pending"
        };
        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        var response = await _db.Enrolments
            .Where(e => e.EnrolmentId == enrolment.EnrolmentId)
            .Select(Dtos.Mapping.EnrolmentProjection)
            .SingleAsync();

        return Created($"/api/enrolments/{enrolment.EnrolmentId}", response);
    }
}
