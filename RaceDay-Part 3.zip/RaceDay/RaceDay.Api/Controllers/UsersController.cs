using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[Route("api/users")]
public class UsersController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public UsersController(RaceDayDbContext db) => _db = db;

    [HttpPut("{userId:int}")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateProfile(int userId, [FromBody] UpdateProfileRequest request)
    {
        if (userId != CurrentUserId)
            return ForbiddenProblem("You can only update your own profile.");

        var user = await _db.Users.Include(u => u.Role).SingleOrDefaultAsync(u => u.UserId == userId);
        if (user == null) return NotFoundProblem("User not found.");

        if (await _db.Users.AnyAsync(u => u.Email == request.Email && u.UserId != userId))
            return ConflictProblem("That email is already in use.");

        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName.Trim();
        user.Email = request.Email.Trim().ToLowerInvariant();
        await _db.SaveChangesAsync();

        return Ok(user.ToResponse(user.Role.RoleName));
    }
}
