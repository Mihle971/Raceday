using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

// ---------- Authentication / Users ----------
public class RegisterRequest
{
    [Required, StringLength(50)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(50)] public string LastName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(100)] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;
    [Required] public string Role { get; set; } = string.Empty;
    public string? OrganiserCode { get; set; }
}

public class LoginRequest
{
    [Required] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public class UpdateProfileRequest
{
    [Required, StringLength(50)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(50)] public string LastName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(100)] public string Email { get; set; } = string.Empty;
}

public class UserResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime DateRegistered { get; set; }
    public string? ProfilePictureUrl { get; set; }
}

// ---------- Events ----------
public class EventRequest
{
    [Required, StringLength(100)] public string EventName { get; set; } = string.Empty;
    [Required] public DateTime? EventDate { get; set; }
    [Required, StringLength(100)] public string Location { get; set; } = string.Empty;
    [StringLength(500)] public string? Description { get; set; }
    [Required, Range(0.01, 9999.99)] public decimal? Distance { get; set; }
    [Required] public string EventType { get; set; } = string.Empty;
}

public class EventResponse
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }
    public decimal Distance { get; set; }
    public string EventType { get; set; } = string.Empty;
    public int OrganiserId { get; set; }
    public string? BannerUrl { get; set; }
}

public class OrganiserEventSummary
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal Distance { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string? BannerUrl { get; set; }
    public int CategoryCount { get; set; }
    public int TotalEnrolments { get; set; }
    public int PendingEnrolments { get; set; }
    public int ResultsPublished { get; set; }
}

// ---------- Categories ----------
public class CategoryRequest
{
    [Required, StringLength(50)] public string CategoryName { get; set; } = string.Empty;
    [Range(1, 100000)] public int MaxParticipants { get; set; } = 100;
}

public class CategoryResponse
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int MaxParticipants { get; set; }
}

// ---------- Enrolments ----------
public class EnrolmentResponse
{
    public int EnrolmentId { get; set; }
    public int UserId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EnrolmentDate { get; set; }
    public string Status { get; set; } = string.Empty;
}

public class EnrolmentStatusRequest
{
    [Required] public string Status { get; set; } = string.Empty;
}

// ---------- Results ----------
public class ResultRequest
{
    [Required] public TimeSpan? FinishTime { get; set; }
    [Range(1, 1000000)] public int? Position { get; set; }
}

public class ResultResponse
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public int UserId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public TimeSpan FinishTime { get; set; }
    public int? Position { get; set; }
    public DateTime CapturedDate { get; set; }
    public bool IsPublished { get; set; }
    public int TotalFinishers { get; set; }
}
