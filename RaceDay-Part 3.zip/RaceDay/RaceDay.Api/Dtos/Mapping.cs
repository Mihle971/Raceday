using System.Linq.Expressions;
using RaceDay.Api.Models;

namespace RaceDay.Api.Dtos;

public static class Mapping
{
    public static UserResponse ToResponse(this User user, string roleName) => new()
    {
        UserId = user.UserId,
        FirstName = user.FirstName,
        LastName = user.LastName,
        Email = user.Email,
        Role = roleName,
        DateRegistered = user.DateRegistered,
        ProfilePictureUrl = user.ProfilePictureUrl
    };

    public static EventResponse ToResponse(this Event e) => new()
    {
        EventId = e.EventId,
        EventName = e.EventName,
        EventDate = e.EventDate,
        Location = e.Location,
        Description = e.Description,
        Distance = e.Distance,
        EventType = e.EventType,
        OrganiserId = e.OrganiserId,
        BannerUrl = e.BannerUrl
    };

    public static CategoryResponse ToResponse(this Category c) => new()
    {
        CategoryId = c.CategoryId,
        EventId = c.EventId,
        CategoryName = c.CategoryName,
        MaxParticipants = c.MaxParticipants
    };

    public static readonly Expression<Func<Enrolment, EnrolmentResponse>> EnrolmentProjection = e => new EnrolmentResponse
    {
        EnrolmentId = e.EnrolmentId,
        UserId = e.UserId,
        ParticipantName = e.User.FirstName + " " + e.User.LastName,
        CategoryId = e.CategoryId,
        CategoryName = e.Category.CategoryName,
        EventId = e.Category.EventId,
        EventName = e.Category.Event.EventName,
        EnrolmentDate = e.EnrolmentDate,
        Status = e.Status
    };

    public static readonly Expression<Func<Result, ResultResponse>> ResultProjection = r => new ResultResponse
    {
        ResultId = r.ResultId,
        EnrolmentId = r.EnrolmentId,
        UserId = r.Enrolment.UserId,
        ParticipantName = r.Enrolment.User.FirstName + " " + r.Enrolment.User.LastName,
        EventId = r.Enrolment.Category.EventId,
        EventName = r.Enrolment.Category.Event.EventName,
        CategoryName = r.Enrolment.Category.CategoryName,
        FinishTime = r.FinishTime,
        Position = r.Position,
        CapturedDate = r.CapturedDate,
        IsPublished = r.IsPublished,
        TotalFinishers = r.Enrolment.Category.Enrolments.Count(en => en.Result != null && en.Result.IsPublished)
    };
}
