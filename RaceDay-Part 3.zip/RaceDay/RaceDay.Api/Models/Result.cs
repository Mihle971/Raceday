namespace RaceDay.Api.Models;

// The outcome for one Enrolment, captured by an Organiser.
public class Result
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }                  // Foreign key -> Enrolment (unique)
    public TimeSpan FinishTime { get; set; }              // Stored as SQL TIME
    public int? Position { get; set; }                    // Optional ranking
    public DateTime CapturedDate { get; set; }
    public bool IsPublished { get; set; }                 // false until the Organiser publishes the results

    public Enrolment Enrolment { get; set; } = null!;
}
