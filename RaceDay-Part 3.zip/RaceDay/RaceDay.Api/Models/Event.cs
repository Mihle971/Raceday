namespace RaceDay.Api.Models;

// One row = one race/walk/ride created by an Organiser.
public class Event
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }              // Optional
    public decimal Distance { get; set; }                 // In km
    public string EventType { get; set; } = string.Empty; // "Run", "Walk" or "Cycle"
    public int OrganiserId { get; set; }                  // Foreign key -> User
    public string? BannerUrl { get; set; }                // Link to the banner image in Azure Blob Storage (optional)

    public User Organiser { get; set; } = null!;
    public List<Category> Categories { get; set; } = new();
}
