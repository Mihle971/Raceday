namespace RaceDay.Api.Models;

// Junction row: "this Participant entered this Category".
public class Enrolment
{
    public int EnrolmentId { get; set; }
    public int UserId { get; set; }                       // Foreign key -> User (the Participant)
    public int CategoryId { get; set; }                   // Foreign key -> Category
    public DateTime EnrolmentDate { get; set; }
    public string Status { get; set; } = "Pending";       // "Pending" until the Organiser confirms, then "Confirmed"

    public User User { get; set; } = null!;
    public Category Category { get; set; } = null!;
    public Result? Result { get; set; }                   // At most ONE result (one-to-one)
}
