namespace RaceDay.Api.Models;

// One row = one registered person (Organiser or Participant).
public class User
{
    public int UserId { get; set; }                       // Primary key
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;     // Used to log in, must be unique
    public string PasswordHash { get; set; } = string.Empty; // NEVER the real password
    public int RoleId { get; set; }                       // Foreign key -> Role
    public DateTime DateRegistered { get; set; }
    public string? ProfilePictureUrl { get; set; }        // Link to the picture in Azure Blob Storage (optional)

    public Role Role { get; set; } = null!;                       // The user's role
    public List<Event> OrganisedEvents { get; set; } = new();     // Events this user created (Organisers)
    public List<Enrolment> Enrolments { get; set; } = new();      // Enrolments this user made (Participants)
}
