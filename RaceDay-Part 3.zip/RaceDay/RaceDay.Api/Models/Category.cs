namespace RaceDay.Api.Models;

public class Category
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int MaxParticipants { get; set; } = 100;

    public Event Event { get; set; } = null!;
    public List<Enrolment> Enrolments { get; set; } = new();
}
