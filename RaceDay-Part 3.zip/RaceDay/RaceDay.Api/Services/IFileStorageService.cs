namespace RaceDay.Api.Services;

public interface IFileStorageService
{
    Task<string> UploadAsync(Stream content, string blobName, string contentType);
}
