using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class ProfileController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public ProfileController(IRaceDayApiClient api) => _api = api;

    public async Task<IActionResult> Index()
    {
        if (!IsLoggedIn) return RequireLogin();

        // Refresh from API so we always show the latest picture URL
        var (ok, user) = await _api.GetCurrentUserAsync();
        if (!ok || user == null)
        {
            TempData["Error"] = "Could not load your profile.";
            return RedirectToAction("Index", "Home");
        }

        SessionUser.Set(HttpContext.Session, user);   // keep session in sync

        var model = new UpdateProfileViewModel
        {
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email
        };
        ViewBag.ProfilePictureUrl = user.ProfilePictureUrl;
        ViewBag.UserId = user.UserId;
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(UpdateProfileViewModel model)
    {
        if (!IsLoggedIn) return RequireLogin();
        if (!ModelState.IsValid) return View("Index", model);

        var (ok, error, user) = await _api.UpdateProfileAsync(CurrentUser!.UserId, model);
        if (!ok || user == null)
        {
            ModelState.AddModelError(string.Empty, error ?? "Update failed.");
            ViewBag.UserId = CurrentUser.UserId;
            return View("Index", model);
        }

        SessionUser.Set(HttpContext.Session, user);
        TempData["Success"] = "Profile updated.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadPicture(IFormFile file)
    {
        if (!IsLoggedIn) return RequireLogin();

        if (file == null || file.Length == 0)
        {
            TempData["Error"] = "Please choose an image.";
            return RedirectToAction(nameof(Index));
        }

        var (ok, error, user) = await _api.UploadProfilePictureAsync(CurrentUser!.UserId, file);
        if (!ok || user == null)
            TempData["Error"] = error ?? "Upload failed.";
        else
        {
            SessionUser.Set(HttpContext.Session, user);
            TempData["Success"] = "Profile picture updated.";
        }

        return RedirectToAction(nameof(Index));
    }
}
