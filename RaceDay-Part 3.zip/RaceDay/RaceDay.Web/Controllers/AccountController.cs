using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class AccountController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public AccountController(IRaceDayApiClient api) => _api = api;

    [HttpGet]
    public IActionResult Register()
    {
        if (IsLoggedIn) return RedirectToAction("Index", "Home");
        return View(new RegisterViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var (ok, error, user) = await _api.RegisterAsync(model);
        if (!ok || user == null)
        {
            ModelState.AddModelError(string.Empty, error ?? "Registration failed.");
            return View(model);
        }

        // Auto-login after successful registration
        SessionUser.Set(HttpContext.Session, user);
        TempData["Success"] = $"Welcome, {user.FirstName}! Your account is ready.";
        return RedirectToRoleHome(user.Role);
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (IsLoggedIn) return RedirectToAction("Index", "Home");
        ViewBag.ReturnUrl = returnUrl;
        return View(new LoginViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
    {
        if (!ModelState.IsValid) return View(model);

        var (ok, error, user) = await _api.LoginAsync(model);
        if (!ok || user == null)
        {
            ModelState.AddModelError(string.Empty, error ?? "Invalid email or password.");
            return View(model);
        }

        SessionUser.Set(HttpContext.Session, user);
        TempData["Success"] = $"Welcome back, {user.FirstName}!";

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);

        return RedirectToRoleHome(user.Role);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await _api.LogoutAsync();
        SessionUser.Clear(HttpContext.Session);
        TempData["Success"] = "You have been logged out.";
        return RedirectToAction("Index", "Home");
    }

    private IActionResult RedirectToRoleHome(string role)
    {
        return role == "Organiser"
            ? RedirectToAction("Dashboard", "Events")
            : RedirectToAction("Index", "Home");
    }
}
