using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class ResultsController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public ResultsController(IRaceDayApiClient api) => _api = api;

    // Participant: My Results
    public async Task<IActionResult> MyResults()
    {
        var gate = RequireParticipant();
        if (gate != null) return gate;

        var list = await _api.GetMyResultsAsync(CurrentUser!.UserId);
        return View(list);
    }
}
