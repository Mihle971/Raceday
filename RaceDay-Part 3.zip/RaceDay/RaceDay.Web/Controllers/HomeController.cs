using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public HomeController(IRaceDayApiClient api) => _api = api;

    public async Task<IActionResult> Index(string? eventType, string? location, bool upcomingOnly = true)
    {
        // Public home page – list upcoming events with optional filters
        var events = await _api.GetEventsAsync(
            eventType: eventType,
            location: location,
            upcomingOnly: upcomingOnly);

        ViewBag.EventType = eventType;
        ViewBag.Location = location;
        ViewBag.UpcomingOnly = upcomingOnly;
        ViewBag.IsParticipant = IsParticipant;
        ViewBag.IsOrganiser = IsOrganiser;

        return View(events);
    }

    public async Task<IActionResult> EventDetails(int id)
    {
        var ev = await _api.GetEventAsync(id);
        if (ev == null)
        {
            TempData["Error"] = "Event not found.";
            return RedirectToAction(nameof(Index));
        }

        var categories = await _api.GetCategoriesForEventAsync(id);
        ViewBag.Categories = categories;
        ViewBag.IsParticipant = IsParticipant;
        ViewBag.CurrentUserId = CurrentUser?.UserId;

        return View(ev);
    }

    public IActionResult Error()
    {
        return View();
    }
}
