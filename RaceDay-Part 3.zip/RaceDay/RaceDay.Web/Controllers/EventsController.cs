using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class EventsController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public EventsController(IRaceDayApiClient api) => _api = api;

    // ---------- Organiser Dashboard ----------
    public async Task<IActionResult> Dashboard()
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var summaries = await _api.GetMyEventsAsync();
        return View(summaries);
    }

    // ---------- CRUD ----------
    [HttpGet]
    public IActionResult Create()
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;
        return View(new EventRequest { EventDate = DateTime.Today.AddDays(14) });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(EventRequest model)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        if (!ModelState.IsValid) return View(model);

        var (ok, error, ev) = await _api.CreateEventAsync(model);
        if (!ok || ev == null)
        {
            ModelState.AddModelError(string.Empty, error ?? "Could not create event.");
            return View(model);
        }

        TempData["Success"] = $"Event \"{ev.EventName}\" created.";
        return RedirectToAction(nameof(Manage), new { id = ev.EventId });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var ev = await _api.GetEventAsync(id);
        if (ev == null)
        {
            TempData["Error"] = "Event not found.";
            return RedirectToAction(nameof(Dashboard));
        }

        var model = new EventRequest
        {
            EventName = ev.EventName,
            EventDate = ev.EventDate,
            Location = ev.Location,
            Description = ev.Description,
            Distance = ev.Distance,
            EventType = ev.EventType
        };
        ViewBag.EventId = id;
        ViewBag.BannerUrl = ev.BannerUrl;
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, EventRequest model)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        if (!ModelState.IsValid)
        {
            ViewBag.EventId = id;
            return View(model);
        }

        var (ok, error, _) = await _api.UpdateEventAsync(id, model);
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error ?? "Could not update event.");
            ViewBag.EventId = id;
            return View(model);
        }

        TempData["Success"] = "Event updated.";
        return RedirectToAction(nameof(Manage), new { id });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var (ok, error) = await _api.DeleteEventAsync(id);
        if (!ok)
            TempData["Error"] = error ?? "Could not delete event.";
        else
            TempData["Success"] = "Event deleted.";

        return RedirectToAction(nameof(Dashboard));
    }

    // ---------- Manage one event (categories, enrolments, results, banner) ----------
    public async Task<IActionResult> Manage(int id)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var ev = await _api.GetEventAsync(id);
        if (ev == null)
        {
            TempData["Error"] = "Event not found.";
            return RedirectToAction(nameof(Dashboard));
        }

        var categories = await _api.GetCategoriesForEventAsync(id);
        var enrolments = await _api.GetEnrolmentsForEventAsync(id);
        var results = await _api.GetResultsForEventAsync(id);

        ViewBag.Event = ev;
        ViewBag.Categories = categories;
        ViewBag.Enrolments = enrolments;
        ViewBag.Results = results;
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadBanner(int id, IFormFile file)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        if (file == null || file.Length == 0)
        {
            TempData["Error"] = "Please choose an image.";
            return RedirectToAction(nameof(Manage), new { id });
        }

        var (ok, error, _) = await _api.UploadBannerAsync(id, file);
        if (!ok)
            TempData["Error"] = error ?? "Upload failed.";
        else
            TempData["Success"] = "Banner uploaded.";

        return RedirectToAction(nameof(Manage), new { id });
    }

    // ---------- Categories ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(int eventId, CategoryRequest model)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Invalid category data.";
            return RedirectToAction(nameof(Manage), new { id = eventId });
        }

        var (ok, error, _) = await _api.CreateCategoryAsync(eventId, model);
        if (!ok)
            TempData["Error"] = error ?? "Could not add category.";
        else
            TempData["Success"] = "Category added.";

        return RedirectToAction(nameof(Manage), new { id = eventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteCategory(int eventId, int categoryId)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var (ok, error) = await _api.DeleteCategoryAsync(categoryId);
        if (!ok)
            TempData["Error"] = error ?? "Could not delete category.";
        else
            TempData["Success"] = "Category deleted.";

        return RedirectToAction(nameof(Manage), new { id = eventId });
    }

    // ---------- Enrolment status ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmEnrolment(int eventId, int enrolmentId)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var (ok, error) = await _api.UpdateEnrolmentStatusAsync(enrolmentId, "Confirmed");
        if (!ok)
            TempData["Error"] = error ?? "Could not update status.";
        else
            TempData["Success"] = "Enrolment confirmed.";

        return RedirectToAction(nameof(Manage), new { id = eventId });
    }

    // ---------- Results ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CaptureResult(int eventId, int enrolmentId, ResultRequest model)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var (ok, error, _) = await _api.CaptureResultAsync(enrolmentId, model);
        if (!ok)
            TempData["Error"] = error ?? "Could not capture result.";
        else
            TempData["Success"] = "Result captured (still unpublished).";

        return RedirectToAction(nameof(Manage), new { id = eventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> PublishResults(int eventId)
    {
        var gate = RequireOrganiser();
        if (gate != null) return gate;

        var (ok, error) = await _api.PublishResultsAsync(eventId);
        if (!ok)
            TempData["Error"] = error ?? "Could not publish results.";
        else
            TempData["Success"] = "Results published. Participants can now see them.";

        return RedirectToAction(nameof(Manage), new { id = eventId });
    }
}
