using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class EnrolmentsController : BaseController
{
    private readonly IRaceDayApiClient _api;

    public EnrolmentsController(IRaceDayApiClient api) => _api = api;

    // Participant enrols for a category
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(int categoryId, int eventId)
    {
        var gate = RequireParticipant();
        if (gate != null) return gate;

        var (ok, error, _) = await _api.EnrolAsync(categoryId);
        if (!ok)
            TempData["Error"] = error ?? "Could not enrol.";
        else
            TempData["Success"] = "You are enrolled! Status is Pending until the organiser confirms.";

        return RedirectToAction("EventDetails", "Home", new { id = eventId });
    }

    // Participant's own enrolments
    public async Task<IActionResult> MyEnrolments()
    {
        var gate = RequireParticipant();
        if (gate != null) return gate;

        var list = await _api.GetMyEnrolmentsAsync(CurrentUser!.UserId);
        return View(list);
    }
}
