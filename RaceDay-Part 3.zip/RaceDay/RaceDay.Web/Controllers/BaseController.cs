using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public abstract class BaseController : Controller
{
    protected CurrentUser? CurrentUser => SessionUser.Get(HttpContext.Session);

    protected bool IsLoggedIn => SessionUser.IsLoggedIn(HttpContext.Session);
    protected bool IsOrganiser => SessionUser.IsOrganiser(HttpContext.Session);
    protected bool IsParticipant => SessionUser.IsParticipant(HttpContext.Session);

    protected IActionResult RequireLogin()
    {
        TempData["Error"] = "Please log in to continue.";
        return RedirectToAction("Login", "Account");
    }

    protected IActionResult RequireOrganiser()
    {
        if (!IsLoggedIn) return RequireLogin();
        if (!IsOrganiser)
        {
            TempData["Error"] = "This page is only for organisers.";
            return RedirectToAction("Index", "Home");
        }
        return null!;
    }

    protected IActionResult RequireParticipant()
    {
        if (!IsLoggedIn) return RequireLogin();
        if (!IsParticipant)
        {
            TempData["Error"] = "This page is only for participants.";
            return RedirectToAction("Index", "Home");
        }
        return null!;
    }
}
