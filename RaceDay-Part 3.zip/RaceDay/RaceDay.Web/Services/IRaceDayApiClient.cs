using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

public interface IRaceDayApiClient
{
    // Auth
    Task<(bool Ok, string? Error, UserDto? User)> RegisterAsync(RegisterViewModel model);
    Task<(bool Ok, string? Error, UserDto? User)> LoginAsync(LoginViewModel model);
    Task LogoutAsync();
    Task<(bool Ok, UserDto? User)> GetCurrentUserAsync();

    // Profile
    Task<(bool Ok, string? Error, UserDto? User)> UpdateProfileAsync(int userId, UpdateProfileViewModel model);
    Task<(bool Ok, string? Error, UserDto? User)> UploadProfilePictureAsync(int userId, IFormFile file);

    // Events
    Task<List<EventDto>> GetEventsAsync(string? eventType = null, string? location = null,
        DateTime? fromDate = null, DateTime? toDate = null, bool upcomingOnly = false);
    Task<EventDto?> GetEventAsync(int eventId);
    Task<(bool Ok, string? Error, EventDto? Event)> CreateEventAsync(EventRequest model);
    Task<(bool Ok, string? Error, EventDto? Event)> UpdateEventAsync(int eventId, EventRequest model);
    Task<(bool Ok, string? Error)> DeleteEventAsync(int eventId);
    Task<List<OrganiserEventSummary>> GetMyEventsAsync();
    Task<(bool Ok, string? Error, EventDto? Event)> UploadBannerAsync(int eventId, IFormFile file);

    // Categories
    Task<List<CategoryDto>> GetCategoriesForEventAsync(int eventId);
    Task<(bool Ok, string? Error, CategoryDto? Category)> CreateCategoryAsync(int eventId, CategoryRequest model);
    Task<(bool Ok, string? Error)> DeleteCategoryAsync(int categoryId);

    // Enrolments
    Task<(bool Ok, string? Error, EnrolmentDto? Enrolment)> EnrolAsync(int categoryId);
    Task<List<EnrolmentDto>> GetMyEnrolmentsAsync(int userId);
    Task<List<EnrolmentDto>> GetEnrolmentsForEventAsync(int eventId);
    Task<(bool Ok, string? Error)> UpdateEnrolmentStatusAsync(int enrolmentId, string status);

    // Results
    Task<(bool Ok, string? Error, ResultDto? Result)> CaptureResultAsync(int enrolmentId, ResultRequest model);
    Task<(bool Ok, string? Error)> PublishResultsAsync(int eventId);
    Task<List<ResultDto>> GetResultsForEventAsync(int eventId);
    Task<List<ResultDto>> GetMyResultsAsync(int userId);
}
