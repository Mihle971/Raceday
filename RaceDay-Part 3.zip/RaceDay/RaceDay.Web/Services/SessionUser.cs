using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

public static class SessionUser
{
    private const string Key = "CurrentUser";

    public static void Set(ISession session, UserDto user)
    {
        var current = new CurrentUser
        {
            UserId = user.UserId,
            FullName = $"{user.FirstName} {user.LastName}",
            Email = user.Email,
            Role = user.Role,
            ProfilePictureUrl = user.ProfilePictureUrl
        };
        session.SetString(Key, System.Text.Json.JsonSerializer.Serialize(current));
    }

    public static CurrentUser? Get(ISession session)
    {
        var json = session.GetString(Key);
        if (string.IsNullOrEmpty(json)) return null;
        return System.Text.Json.JsonSerializer.Deserialize<CurrentUser>(json);
    }

    public static void Clear(ISession session) => session.Remove(Key);

    public static bool IsOrganiser(ISession session) =>
        Get(session)?.Role == "Organiser";

    public static bool IsParticipant(ISession session) =>
        Get(session)?.Role == "Participant";

    public static bool IsLoggedIn(ISession session) => Get(session) != null;
}
