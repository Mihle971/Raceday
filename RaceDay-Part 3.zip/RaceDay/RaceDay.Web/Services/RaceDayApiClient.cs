using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

public class RaceDayApiClient : IRaceDayApiClient
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private const string SessionCookieKey = "ApiSessionCookie";

    public RaceDayApiClient(HttpClient http, IHttpContextAccessor httpContextAccessor)
    {
        _http = http;
        _httpContextAccessor = httpContextAccessor;
    }

    // ---------- helpers ----------
    private void AttachSessionCookie(HttpRequestMessage request)
    {
        var session = _httpContextAccessor.HttpContext?.Session;
        var cookie = session?.GetString(SessionCookieKey);
        if (!string.IsNullOrEmpty(cookie))
        {
            request.Headers.Add("Cookie", cookie);
        }
    }

    private void CaptureSessionCookie(HttpResponseMessage response)
    {
        if (response.Headers.TryGetValues("Set-Cookie", out var values))
        {
            // Keep the first cookie (the API session cookie)
            var cookie = values.FirstOrDefault();
            if (!string.IsNullOrEmpty(cookie))
            {
                // Store only the name=value part
                var pure = cookie.Split(';')[0];
                _httpContextAccessor.HttpContext?.Session.SetString(SessionCookieKey, pure);
            }
        }
    }

    private async Task<T?> ReadJsonAsync<T>(HttpResponseMessage response)
    {
        var json = await response.Content.ReadAsStringAsync();
        if (string.IsNullOrWhiteSpace(json)) return default;
        return JsonSerializer.Deserialize<T>(json, JsonOptions);
    }

    private static StringContent JsonBody(object obj) =>
        new(JsonSerializer.Serialize(obj), Encoding.UTF8, "application/json");

    private async Task<(bool Ok, string? Error, T? Data)> SendAsync<T>(
        HttpMethod method, string url, object? body = null, IFormFile? file = null, string? fileFieldName = null)
    {
        using var request = new HttpRequestMessage(method, url);
        AttachSessionCookie(request);

        if (file != null && fileFieldName != null)
        {
            var content = new MultipartFormDataContent();
            var streamContent = new StreamContent(file.OpenReadStream());
            streamContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
            content.Add(streamContent, fileFieldName, file.FileName);
            request.Content = content;
        }
        else if (body != null)
        {
            request.Content = JsonBody(body);
        }

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request);
        }
        catch (Exception ex)
        {
            return (false, $"Cannot reach the API: {ex.Message}", default);
        }

        CaptureSessionCookie(response);

        if (response.IsSuccessStatusCode)
        {
            var data = await ReadJsonAsync<T>(response);
            return (true, null, data);
        }

        // Try to pull a useful error message from ProblemDetails
        string error = response.StatusCode switch
        {
            HttpStatusCode.Unauthorized => "You must be logged in.",
            HttpStatusCode.Forbidden => "You do not have permission to do that.",
            HttpStatusCode.NotFound => "The requested item was not found.",
            HttpStatusCode.Conflict => "This action conflicts with existing data.",
            HttpStatusCode.ServiceUnavailable => "File storage is not available right now.",
            _ => $"API error ({(int)response.StatusCode})"
        };

        try
        {
            var problem = await ReadJsonAsync<Dictionary<string, object>>(response);
            if (problem != null && problem.TryGetValue("detail", out var detail))
                error = detail?.ToString() ?? error;
        }
        catch { /* ignore */ }

        return (false, error, default);
    }

    // ---------- Auth ----------
    public async Task<(bool Ok, string? Error, UserDto? User)> RegisterAsync(RegisterViewModel model)
    {
        var payload = new
        {
            model.FirstName,
            model.LastName,
            model.Email,
            model.Password,
            model.Role,
            model.OrganiserCode
        };
        return await SendAsync<UserDto>(HttpMethod.Post, "api/auth/register", payload);
    }

    public async Task<(bool Ok, string? Error, UserDto? User)> LoginAsync(LoginViewModel model)
    {
        var payload = new { model.Email, model.Password };
        return await SendAsync<UserDto>(HttpMethod.Post, "api/auth/login", payload);
    }

    public async Task LogoutAsync()
    {
        await SendAsync<object>(HttpMethod.Post, "api/auth/logout");
        _httpContextAccessor.HttpContext?.Session.Remove(SessionCookieKey);
        _httpContextAccessor.HttpContext?.Session.Clear();
    }

    public async Task<(bool Ok, UserDto? User)> GetCurrentUserAsync()
    {
        var (ok, _, user) = await SendAsync<UserDto>(HttpMethod.Get, "api/auth/me");
        return (ok, user);
    }

    // ---------- Profile ----------
    public async Task<(bool Ok, string? Error, UserDto? User)> UpdateProfileAsync(int userId, UpdateProfileViewModel model)
    {
        return await SendAsync<UserDto>(HttpMethod.Put, $"api/users/{userId}", model);
    }

    public async Task<(bool Ok, string? Error, UserDto? User)> UploadProfilePictureAsync(int userId, IFormFile file)
    {
        return await SendAsync<UserDto>(HttpMethod.Post, $"api/users/{userId}/profile-picture",
            file: file, fileFieldName: "file");
    }

    // ---------- Events ----------
    public async Task<List<EventDto>> GetEventsAsync(string? eventType = null, string? location = null,
        DateTime? fromDate = null, DateTime? toDate = null, bool upcomingOnly = false)
    {
        var qs = new List<string>();
        if (!string.IsNullOrWhiteSpace(eventType)) qs.Add($"eventType={Uri.EscapeDataString(eventType)}");
        if (!string.IsNullOrWhiteSpace(location)) qs.Add($"location={Uri.EscapeDataString(location)}");
        if (fromDate.HasValue) qs.Add($"fromDate={fromDate:yyyy-MM-dd}");
        if (toDate.HasValue) qs.Add($"toDate={toDate:yyyy-MM-dd}");
        if (upcomingOnly) qs.Add("upcomingOnly=true");

        var url = "api/events" + (qs.Count > 0 ? "?" + string.Join("&", qs) : "");
        var (ok, _, list) = await SendAsync<List<EventDto>>(HttpMethod.Get, url);
        return list ?? new List<EventDto>();
    }

    public async Task<EventDto?> GetEventAsync(int eventId)
    {
        var (ok, _, ev) = await SendAsync<EventDto>(HttpMethod.Get, $"api/events/{eventId}");
        return ok ? ev : null;
    }

    public async Task<(bool Ok, string? Error, EventDto? Event)> CreateEventAsync(EventRequest model)
    {
        return await SendAsync<EventDto>(HttpMethod.Post, "api/events", model);
    }

    public async Task<(bool Ok, string? Error, EventDto? Event)> UpdateEventAsync(int eventId, EventRequest model)
    {
        return await SendAsync<EventDto>(HttpMethod.Put, $"api/events/{eventId}", model);
    }

    public async Task<(bool Ok, string? Error)> DeleteEventAsync(int eventId)
    {
        var (ok, err, _) = await SendAsync<object>(HttpMethod.Delete, $"api/events/{eventId}");
        return (ok, err);
    }

    public async Task<List<OrganiserEventSummary>> GetMyEventsAsync()
    {
        var (ok, _, list) = await SendAsync<List<OrganiserEventSummary>>(HttpMethod.Get, "api/events/mine");
        return list ?? new List<OrganiserEventSummary>();
    }

    public async Task<(bool Ok, string? Error, EventDto? Event)> UploadBannerAsync(int eventId, IFormFile file)
    {
        return await SendAsync<EventDto>(HttpMethod.Post, $"api/events/{eventId}/banner",
            file: file, fileFieldName: "file");
    }

    // ---------- Categories ----------
    public async Task<List<CategoryDto>> GetCategoriesForEventAsync(int eventId)
    {
        var (ok, _, list) = await SendAsync<List<CategoryDto>>(HttpMethod.Get, $"api/events/{eventId}/categories");
        return list ?? new List<CategoryDto>();
    }

    public async Task<(bool Ok, string? Error, CategoryDto? Category)> CreateCategoryAsync(int eventId, CategoryRequest model)
    {
        return await SendAsync<CategoryDto>(HttpMethod.Post, $"api/events/{eventId}/categories", model);
    }

    public async Task<(bool Ok, string? Error)> DeleteCategoryAsync(int categoryId)
    {
        var (ok, err, _) = await SendAsync<object>(HttpMethod.Delete, $"api/categories/{categoryId}");
        return (ok, err);
    }

    // ---------- Enrolments ----------
    public async Task<(bool Ok, string? Error, EnrolmentDto? Enrolment)> EnrolAsync(int categoryId)
    {
        return await SendAsync<EnrolmentDto>(HttpMethod.Post, $"api/categories/{categoryId}/enrolments");
    }

    public async Task<List<EnrolmentDto>> GetMyEnrolmentsAsync(int userId)
    {
        var (ok, _, list) = await SendAsync<List<EnrolmentDto>>(HttpMethod.Get, $"api/users/{userId}/enrolments");
        return list ?? new List<EnrolmentDto>();
    }

    public async Task<List<EnrolmentDto>> GetEnrolmentsForEventAsync(int eventId)
    {
        var (ok, _, list) = await SendAsync<List<EnrolmentDto>>(HttpMethod.Get, $"api/events/{eventId}/enrolments");
        return list ?? new List<EnrolmentDto>();
    }

    public async Task<(bool Ok, string? Error)> UpdateEnrolmentStatusAsync(int enrolmentId, string status)
    {
        var (ok, err, _) = await SendAsync<object>(HttpMethod.Put, $"api/enrolments/{enrolmentId}/status",
            new { Status = status });
        return (ok, err);
    }

    // ---------- Results ----------
    public async Task<(bool Ok, string? Error, ResultDto? Result)> CaptureResultAsync(int enrolmentId, ResultRequest model)
    {
        // Convert "hh:mm:ss" string into a TimeSpan that the API expects
        if (!TimeSpan.TryParse(model.FinishTime, out var ts))
            return (false, "Finish time must be in hh:mm:ss format.", null);

        var payload = new { FinishTime = ts, model.Position };
        return await SendAsync<ResultDto>(HttpMethod.Post, $"api/enrolments/{enrolmentId}/results", payload);
    }

    public async Task<(bool Ok, string? Error)> PublishResultsAsync(int eventId)
    {
        var (ok, err, _) = await SendAsync<object>(HttpMethod.Post, $"api/events/{eventId}/results/publish");
        return (ok, err);
    }

    public async Task<List<ResultDto>> GetResultsForEventAsync(int eventId)
    {
        var (ok, _, list) = await SendAsync<List<ResultDto>>(HttpMethod.Get, $"api/events/{eventId}/results");
        return list ?? new List<ResultDto>();
    }

    public async Task<List<ResultDto>> GetMyResultsAsync(int userId)
    {
        var (ok, _, list) = await SendAsync<List<ResultDto>>(HttpMethod.Get, $"api/users/{userId}/results");
        return list ?? new List<ResultDto>();
    }
}
