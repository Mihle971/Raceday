# RaceDay – MVC Front-End (Part 3)

ASP.NET Core 8 MVC application that consumes the RaceDay REST API.

## Features

- Session-based authentication (register / login / logout) via the API
- Role-specific navigation and pages (Organiser vs Participant)
- Organiser: dashboard, event CRUD, banner upload, categories, enrolments, results capture & publish
- Participant: browse + filter events, enrol, view own enrolments & published results, profile + picture
- All file uploads go through the API → Azure Blob Storage
- Colour-coded enrolment status (Pending = amber, Confirmed = green)
- Responsive Bootstrap 5 UI with a sporting RaceDay theme
- Docker-ready

## Prerequisites

- .NET 8 SDK
- Running RaceDay API (with the Part 3 Stage A updates applied)
- (Optional) Azure Blob Storage connection string configured on the API

## Configuration

Edit `appsettings.Development.json` (or `appsettings.json`):

```json
"ApiSettings": {
  "BaseUrl": "https://localhost:7xxx/"
}
```

Replace `7xxx` with the port your API is listening on (check `launchSettings.json` of the API project).

## Run locally

```bash
cd RaceDay.Web
dotnet restore
dotnet run
```

Open the URL shown in the console (usually https://localhost:7yyy).

## Docker

Build:

```bash
docker build -t raceday-web .
```

Run (point the container at your API):

```bash
docker run -p 8080:8080 \
  -e ApiSettings__BaseUrl=http://host.docker.internal:5xxx/ \
  raceday-web
```

Then open http://localhost:8080.

> On Linux you may need `--add-host=host.docker.internal:host-gateway`.

## Project structure

```
RaceDay.Web/
├── Controllers/          Account, Home, Events, Enrolments, Results, Profile
├── Models/               ViewModels + DTOs that match the API
├── Services/             IRaceDayApiClient + RaceDayApiClient (HttpClient + session cookie forwarding)
├── Views/                Razor views with Bootstrap layout
├── wwwroot/css/site.css  RaceDay theme
├── Dockerfile
└── README.md
```

## Important design decisions

1. **No database access** – the MVC project never references Entity Framework or any connection string.
2. **API session cookie** – the `RaceDayApiClient` captures the `Set-Cookie` header from login/register and attaches it on every subsequent request. The cookie is stored in the MVC session.
3. **Role checks** – controllers call `RequireOrganiser()` / `RequireParticipant()` which redirect unauthenticated or wrong-role users.
4. **Image uploads** – multipart form posts go straight to the API endpoints (`/api/events/{id}/banner` and `/api/users/{id}/profile-picture`).

## Suggested Git commits

1. Scaffold MVC project + Program.cs + session + HttpClient
2. Add models and RaceDayApiClient
3. Account controller + Login/Register views
4. Home + Event details + filtering
5. Organiser dashboard, create/edit/manage event
6. Categories, enrolment confirmation, results capture/publish
7. Participant enrolments & results pages
8. Profile + picture upload
9. Theme CSS + layout polish
10. Dockerfile + README

## YouTube demo tips

Show:

1. Register as Organiser → create event → upload banner → add categories
2. Register as Participant → enrol → organiser confirms
3. Organiser captures results → publishes → participant sees “47th of 312”
4. Profile picture upload
5. Docker run command working
