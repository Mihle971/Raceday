# RaceDay.Api.Tests

Place your existing unit tests here (or the ExtendedFeatureTests from Stage A).

The project already references RaceDay.Api and has xUnit + EF InMemory packages.
